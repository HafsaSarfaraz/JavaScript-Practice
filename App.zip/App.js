import { useState } from 'react';
import { StyleSheet, Text, View, Button, Image, } from 'react-native';
export default function App() {
  const[press, Setpress]= useState(false);
  const obj={
    name:'Hafsa',
    age:'20',
    Email:'hafsarfaraz@gmail.com',
    address:'ghouriTownPhase4B'
  }

   function handleChange(){
       Setpress(true)
   }
  return (
   <View style={styles.container}>
      <View style={styles.inner}>
            <Image source={require('./assets/profileImg.jpg')} style={styles.img}/>
            <Text style={{fontSize:20, fontWeight:400}}>{obj.name}</Text>
            <Text style={{fontSize:15, fontWeight:300}} >{obj.age}</Text>
            <Text style={{fontSize:13, fontWeight:200, color:'green'}}>{obj['age'] > 18 && 'Verified'}</Text>
            <Button title='show More Info' onPress={handleChange} style={{padding:40, borderWidth: 4, borderRadius:12, borderColor:'white'}} />

            {Setpress && <View style={{height:100, width: 100, backgroundColor:'white',color:'black'}}>
              <Text>Email: obj['Email']</Text>
              <Text>Address: obj['address']</Text>
              </View>}
      </View>
   </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'pink',
    justifyContent:'center',
    alignItems:'center'
  },
   inner:{
    height:500,
    width:500,
    backgroundColor:'purple',
    flexDirection:'column',
    justifyContent:'center',
   },

   img:{
    height: 50,
    width:50,
     borderRadius:'50%'
   }

});